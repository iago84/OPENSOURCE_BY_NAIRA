
from django.contrib import admin
from .models import PRODUCTS, CARTS, SURVEY

admin.site.register(PRODUCTS)
admin.site.register(CARTS)
admin.site.register(SURVEY)
