
from django.contrib import admin
from .models import PROFILE, TASK, TAGS, ASSIGNATION

admin.site.register(PROFILE)
admin.site.register(TASK)
admin.site.register(TAGS)
admin.site.register(ASSIGNATION)
